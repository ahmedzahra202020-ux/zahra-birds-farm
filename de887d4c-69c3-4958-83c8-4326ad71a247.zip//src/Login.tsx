import React, { useState } from "react";

type Props = {
  onLogin: () => void;
};

export default function Login({ onLogin }: Props) {
  const [username, setUsername] = useState("");

  const [password, setPassword] = useState("");

  const login = () => {
    if (username === "admin" && password === "1234") {
      onLogin();
    } else {
      alert("بيانات الدخول غير صحيحة");
    }
  };

  return (
    <div
      style={{
        minHeight: "100vh",

        display: "flex",

        justifyContent: "center",

        alignItems: "center",

        background: "linear-gradient(to bottom,#020617,#111827)",

        padding: 20,
      }}
    >
      <div
        style={{
          width: "100%",

          maxWidth: 350,

          background: "rgba(255,255,255,0.08)",

          backdropFilter: "blur(10px)",

          padding: 25,

          borderRadius: 20,

          border: "1px solid rgba(255,255,255,0.1)",
        }}
      >
        <h1
          style={{
            color: "white",

            textAlign: "center",

            marginBottom: 25,
          }}
        >
          🔐 Login
        </h1>

        <input
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="Username"
          style={inputStyle}
        />

        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          style={inputStyle}
        />

        <button onClick={login} style={buttonStyle}>
          دخول
        </button>

        <p
          style={{
            color: "#cbd5e1",

            marginTop: 20,

            textAlign: "center",

            fontSize: 14,
          }}
        >
          Username: admin
          <br />
          Password: 1234
        </p>
      </div>
    </div>
  );
}

const inputStyle = {
  width: "100%",

  padding: 14,

  marginBottom: 15,

  borderRadius: 12,

  border: "none",

  background: "#1e293b",

  color: "white",
};

const buttonStyle = {
  width: "100%",

  padding: 14,

  border: "none",

  borderRadius: 12,

  background: "#22c55e",

  color: "white",

  fontWeight: "bold" as const,
};
