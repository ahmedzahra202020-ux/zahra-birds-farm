import React, { useEffect, useState } from "react";

export default function Inventory() {
  const [item, setItem] = useState("");

  const [quantity, setQuantity] = useState("");

  const [inventory, setInventory] = useState<any[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem("inventory");

    if (saved) {
      setInventory(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("inventory", JSON.stringify(inventory));
  }, [inventory]);

  const addItem = () => {
    if (!item) return;

    const newItem = {
      item,

      quantity,
    };

    setInventory([...inventory, newItem]);

    setItem("");

    setQuantity("");
  };

  const deleteItem = (index: number) => {
    const updated = inventory.filter((_, i) => i !== index);

    setInventory(updated);
  };

  return (
    <div
      style={{
        minHeight: "100vh",

        padding: 20,

        background: "linear-gradient(to bottom,#020617,#111827)",

        color: "white",
      }}
    >
      <h1>📦 المخزون</h1>

      <input
        value={item}
        onChange={(e) => setItem(e.target.value)}
        placeholder="اسم المنتج"
        style={inputStyle}
      />

      <input
        value={quantity}
        onChange={(e) => setQuantity(e.target.value)}
        placeholder="الكمية"
        style={inputStyle}
      />

      <button onClick={addItem} style={buttonStyle}>
        ➕ إضافة
      </button>

      <div
        style={{
          marginTop: 20,
        }}
      >
        {inventory.map((data, index) => (
          <div
            key={index}
            style={{
              background: "#1e293b",

              padding: 16,

              borderRadius: 18,

              marginBottom: 15,
            }}
          >
            <h2>📦 {data.item}</h2>

            <p>
              🔢 الكمية:
              {data.quantity}
            </p>

            <button
              onClick={() => deleteItem(index)}
              style={{
                marginTop: 10,

                border: "none",

                padding: "10px 14px",

                borderRadius: 10,

                background: "#dc2626",

                color: "white",
              }}
            >
              حذف
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

const inputStyle = {
  width: "100%",

  padding: 14,

  marginTop: 10,

  borderRadius: 12,

  border: "none",

  background: "#1e293b",

  color: "white",
};

const buttonStyle = {
  width: "100%",

  padding: 14,

  marginTop: 10,

  border: "none",

  borderRadius: 12,

  background: "#22c55e",

  color: "white",

  fontWeight: "bold" as const,
};
